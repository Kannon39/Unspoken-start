﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Unspoken
{
    class Approach
    {
        //TODO: Make a double for approaching a character

        public string LocationName { get; }
        public string LocationDesc { get; }
        public Character LocationChar { get; }
        public Item ApproachItem { get; }


        public Approach(string name, string description, Character character, Item item)
        {
            LocationName = name;
            LocationDesc = description;
            LocationChar = character;
            ApproachItem = item;
        }
    }
}
