﻿using System;
using System.Collections.Generic;
using System.Text;
using static System.Console;

namespace Unspoken
{
    class Player
    {

        //TODO: Make a string for the players name 
        public string playerName { get; private set; }

        //TODO: Make a bool for taking items
        private List<Item> PlayerInventory = new List<Item>();

        public Player()
        {

        }

        public Player(string name)
        {
            playerName = name;
        }

        public void UpdateName(string name)
        {
            playerName = name;
        }


        //TODO: Make a double for location
        //public Approach playerLocation;


        //TODO: Make an inventory
        public string UpdateInventory(Item i)
        {
            string result;
            if (this.PlayerInventory.Contains(i))
            {
                result = "Place Holder";
            }
            else
            {
                this.PlayerInventory.Add(i);
                result = $"{i.ItemName} has been collected";
            }

            return result;
        }

        public string DisplayInventory()
        {
            StringBuilder result = new StringBuilder();

            foreach (var item in PlayerInventory)
            {
                result.Append($"{item.ItemName}");
            }

            return result.ToString();

        }


        public int CheckInventory()
        {
            return this.PlayerInventory.Count;
        }

    }
}
