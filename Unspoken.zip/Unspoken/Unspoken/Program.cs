﻿using System;
using static System.Console;

namespace Unspoken
{
    class Program
    {
        static void Main(string[] args)
        {

            Game myGame = new Game();
            myGame.Start();

        }
    }
}
