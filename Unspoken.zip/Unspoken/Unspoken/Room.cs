﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Unspoken
{
    class Room
    {

        //public string RoomName { get; private set; }

        //public Room()

        //TODO: Make a bool for the search in different rooms


        //TODO: Make a (string?)(list?)bool for the interaction of items


        //TODO: Make an something that gives a random amount of a certain item(int)
    }
}
