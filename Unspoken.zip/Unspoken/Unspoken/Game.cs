﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using System.IO;

namespace Unspoken
{
    class Game
    {

        public Game()
        {
            LoadGameData();
        }

        public void Start()
        {
            Title = "Unspoken";
            RunMainMenu();
            Play();
            EndGame();
            
        }

        private void RunMainMenu()
        {

            string prompt = @"
 ▄         ▄  ▄▄        ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄    ▄  ▄▄▄▄▄▄▄▄▄▄▄  ▄▄        ▄ 
▐░▌       ▐░▌▐░░▌      ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░░▌      ▐░▌
▐░▌       ▐░▌▐░▌░▌     ▐░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░█▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀█░▌▐░▌ ▐░▌ ▐░█▀▀▀▀▀▀▀▀▀ ▐░▌░▌     ▐░▌
▐░▌       ▐░▌▐░▌▐░▌    ▐░▌▐░▌          ▐░▌       ▐░▌▐░▌       ▐░▌▐░▌▐░▌  ▐░▌          ▐░▌▐░▌    ▐░▌
▐░▌       ▐░▌▐░▌ ▐░▌   ▐░▌▐░█▄▄▄▄▄▄▄▄▄ ▐░█▄▄▄▄▄▄▄█░▌▐░▌       ▐░▌▐░▌░▌   ▐░█▄▄▄▄▄▄▄▄▄ ▐░▌ ▐░▌   ▐░▌
▐░▌       ▐░▌▐░▌  ▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░░░░░░░░░░░▌▐░▌       ▐░▌▐░░▌    ▐░░░░░░░░░░░▌▐░▌  ▐░▌  ▐░▌
▐░▌       ▐░▌▐░▌   ▐░▌ ▐░▌ ▀▀▀▀▀▀▀▀▀█░▌▐░█▀▀▀▀▀▀▀▀▀ ▐░▌       ▐░▌▐░▌░▌   ▐░█▀▀▀▀▀▀▀▀▀ ▐░▌   ▐░▌ ▐░▌
▐░▌       ▐░▌▐░▌    ▐░▌▐░▌          ▐░▌▐░▌          ▐░▌       ▐░▌▐░▌▐░▌  ▐░▌          ▐░▌    ▐░▌▐░▌
▐░█▄▄▄▄▄▄▄█░▌▐░▌     ▐░▐░▌ ▄▄▄▄▄▄▄▄▄█░▌▐░▌          ▐░█▄▄▄▄▄▄▄█░▌▐░▌ ▐░▌ ▐░█▄▄▄▄▄▄▄▄▄ ▐░▌     ▐░▐░▌
▐░░░░░░░░░░░▌▐░▌      ▐░░▌▐░░░░░░░░░░░▌▐░▌          ▐░░░░░░░░░░░▌▐░▌  ▐░▌▐░░░░░░░░░░░▌▐░▌      ▐░░▌
 ▀▀▀▀▀▀▀▀▀▀▀  ▀        ▀▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀            ▀▀▀▀▀▀▀▀▀▀▀  ▀    ▀  ▀▀▀▀▀▀▀▀▀▀▀  ▀        ▀▀ 
                                                                                                   
Welcome to the game of unspoken stories
(Use the Arrow Keys to cycle through options and press Enter to select!)";
            string[] options = { "Play", "About", "Credits", "Exit" };
            Menu mainMenu = new Menu(prompt, options);
            int selectedIndex = mainMenu.Run();

            switch (selectedIndex)
            {
                case 0:
                    PlayerSetUp();
                    break;
                case 1:
                    AboutInfo();
                    break;
                case 2:
                    Credits();
                    break;
                case 3:
                    ExitGame();
                    break;
            }




        }

        private Player myPlayer = new Player();
        private List<Approach> approaches = new List<Approach>();
        private List<Item> items = new List<Item>();
        private List<string> levelDialogue = new List<string>();
        private string gameData = "TextFile1.txt";

        //TODO: Make dualogue for different characters

        public void LoadGameData()
        {
            foreach (var item in File.ReadAllLines(gameData))
            {
                var fields = item.Split(';');
                approaches.Add(new Approach(fields[0],fields[1],new Character(fields[2]),new Item(fields[3])));
            }
        }

        private void ExitGame()
        {
            WriteLine("\nPress any key to exit...");
            ReadKey(true);
            Environment.Exit(0);
        }

        private void AboutInfo()
        {
            Clear();
            WriteLine("Place holder for About info");
            //TODO: Write info about the game. ie. premise
            WriteLine("Press any key to return to the menu");
            ReadKey(true);
            RunMainMenu();

        }

        private void Credits()
        {
            Clear();
            WriteLine(@"Menu movement was obtained from Michael Hadley. 
From his youtube video 'Intro to C#: 29 - Making a Fancy Keyboard-Controlled Console Menu
https://youtu.be/qAWhGEPMlS8");
            //TODO: Give links and credits of all things used for the game
            ReadKey(true);
            RunMainMenu();
        }

        private void PlayerSetUp()
        {
            Clear();

            WriteLine($"Welcome to Unspoken\nA game where your choices matter");

            while (true)
            {
                WriteLine($"\n\nWhat is your name?");

                myPlayer.UpdateName(ReadLine());

                WriteLine($"Welcome {myPlayer.playerName} \n\nPress enter to continue");

                ConsoleKeyInfo input = ReadKey();

                if (input.Key == ConsoleKey.Enter)
                {
                    break;
                }

                Clear();
            }

            Clear();
        }

        public void Play()
        {
            Clear();
            WriteLine($"You wake up at the sound of your alarm. You groan as you turn to turn it off \n\nUgh, I can't believe its Monday again");
            ReadKey();
            WriteLine($"\nYou let out a sigh as you make yourself a coffee after getting ready. \n\n'Jeez, that took way longer than I thought it would' you say to yourself");
            ReadKey();
            WriteLine("\nLooking around you see your neighbor next door, struggling with some boxes. \n\n'Oh, new neighbors'");
            ReadKey();
            WriteLine("\n\nWhat would you like to do? Press one to help or two to continue with your day");

            //suggestion: Print a list of things/location
            for (int i = 0; i < approaches.Count; i++)
            {
                WriteLine($"{i + 1}: {approaches[i].LocationName}");
            }

            ConsoleKeyInfo input = ReadKey();

            if (input.Key == ConsoleKey.D1)
            {
                //Travel();
            }
            else
            {

            }

        }

        public void Travel(Approach a, int dialogue)
        {
            Clear();
            WriteLine($"Placeholder");
        }

        public void EndGame()
        {
            Clear();
            WriteLine("Placeholder");
            ReadKey(true);
            Clear();
            WriteLine("Press Enter to go back to the main menu");

            ConsoleKeyInfo input = ReadKey();
          
            if (input.Key == ConsoleKey.Enter)
            {
                RunMainMenu();
            }
            else
            {
                EndGame();
            }
        }

    }

}
